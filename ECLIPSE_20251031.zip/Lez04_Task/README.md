# Task 20251030

Creare un piccolo sistema di gestione libri su Spring Boot, all'interno di un singolo Controller inserire un attributo Lista (ArrayList già inizializzato). Che preveda i seguenti Endpoint:

- GET - elenco -> Restituisce tutti gli elementi
- POST - nuovo -> Aggiunge un nuovo elemento
- DELETE - elimina -> Elimina un elemento già presente identificato dal suo ISBN.

Struttura degli oggetti:
- titolo: string
- autore: string
- prezzo: float
- isbn: string