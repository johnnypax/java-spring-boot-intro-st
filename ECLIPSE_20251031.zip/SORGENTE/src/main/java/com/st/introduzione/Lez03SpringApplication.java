package com.st.introduzione;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lez03SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lez03SpringApplication.class, args);
	}

}
